#!/usr/bin/python
import os, sys, random
def gerar_nome_alea():
	ret=""
	cont=0	
	cond=0
	lista=os.listdir(os.getcwd()) 
	while(cond==0):
		cond=1
		while(cont<30):
			ret=ret+chr(random.randint(97,122))
			cont=cont+1
		
		for arq in lista:	
			if(arq==ret):				
				ret=""		
				cond=0
				break			
	return ret
	
arg = sys.argv[1:]
ini=0;
dire=""
lista=os.listdir(os.getcwd()) 
lista.sort()
mani_arq=[]
for arq in lista:	
	arq_temp=arq.split(".")
	if(len(arq_temp)>1):
		if(arq_temp[1]=="jpg" or arq_temp[1]=="jpeg" or arq_temp[1]=="JPG" or arq_temp[1]=="jPEG" or arq_temp[1]=="tif"):
			temp="convert -resize '"+arg[0]+"x"+arg[1]+"'! "+arq+" "+arq_temp[0]+"_copia.jpg"
			mani_arq.append(arq_temp[0]+"_copia.jpg")
			os.system(temp)	

str_arq_mencoder=gerar_nome_alea()
arq_mencoder=open (str_arq_mencoder, "w")
quadros_segundos= int(round(30.0/float(arg[2])))
fps=30
if(float(quadros_segundos)<1.0):
	quadros_segundos=1
	fps=int(arg[2])
	
for arq in mani_arq:	
	cont=0
	while(cont<quadros_segundos):
		arq_mencoder.write(arq+"\n")
		cont=cont+1
	
arq_mencoder.close()


#-of lavf -lavfopts format=mp4 -oac lavc -ovc lavc -lavcopts aglobal=1:vglobal=1:acodec=libfaac:abitrate=128:vcodec=mpeg4:keyint=25 -ofps 25 -af lavcresample=44100 -vf harddup,scale=480:-3 -mc 0 -noskip MOVIE.avi -o MOVIE.mp4
os.system("mencoder mf://@"+str_arq_mencoder+" -mf w="+arg[0]+":h="+arg[1]+":fps="+str(fps)+" -ovc x264 -x264encopts threads=auto:bframes=3:weight_b:partitions=all:8x8dct:subq=6:bitrate=8100 -o "+arg[3] )

for arq in mani_arq:
	os.remove(arq)

os.remove(str_arq_mencoder)

