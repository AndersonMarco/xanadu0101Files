#!/usr/bin/python
import os, sys, random
def gerar_nome_alea():
	ret=""
	cont=0	
	cond=0
	lista=os.listdir(os.getcwd()) 
	while(cond==0):
		cond=1
		while(cont<30):
			ret=ret+chr(random.randint(97,122))
			cont=cont+1
		
		for arq in lista:	
			if(arq==ret):				
				ret=""		
				cond=0
				break			
	return ret
	
arg = sys.argv[1:]
ini=0;
dire=""
lista=os.listdir(os.getcwd()) 
lista.sort()
mani_arq=[]
for arq in lista:	
	arq_temp=arq.split(".")
	if(len(arq_temp)>1):
		if(arq_temp[1]=="jpg" or arq_temp[1]=="jpeg" or arq_temp[1]=="JPG" or arq_temp[1]=="jPEG"):
			temp="convert -resize '"+arg[0]+"x"+arg[1]+"'! "+arq+" "+arq_temp[0]+"_copia.jpg"
			mani_arq.append(arq_temp[0]+"_copia.jpg")
			os.system(temp)	

str_arq_mencoder=gerar_nome_alea()
arq_mencoder=open (str_arq_mencoder, "w")
quadros_segundos= int(float(arg[2])*25)
for arq in mani_arq:	
	cont=0
	while(cont<quadros_segundos):
		arq_mencoder.write(arq+"\n")
		cont=cont+1
	
arq_mencoder.close()


os.system("mencoder mf://@"+str_arq_mencoder+" -mf w="+arg[0]+":h="+arg[1]+":fps=25 -ovc lavc -lavcopts vcodec=mpeg4:mbd=2:trell -oac copy -o "+arg[3])


for arq in mani_arq:
	os.remove(arq)

os.remove(str_arq_mencoder)

