#include <QObject>
#include <QString>
#include <QVariantList>
#include <QMap>
#include <QVariant>
#include <QDebug>
#include <QTextStream>
#include <QFile>
#include <QIODevice>
#include <stdlib.h>

class SlotForCallCPlusPlusCode : public QObject
{
     Q_OBJECT

 public:
     SlotForCallCPlusPlusCode(QString applicationDirPath) { 
         this->applicationDirPath=applicationDirPath;
     }
     public slots:
     QString cplusplusCodeToCall(QString stringJavaScriptPackagedInQt,const QVariantList& vetJavaScriptPackagedInQt, int intJavaScript);
 private:
     QString applicationDirPath;
};
