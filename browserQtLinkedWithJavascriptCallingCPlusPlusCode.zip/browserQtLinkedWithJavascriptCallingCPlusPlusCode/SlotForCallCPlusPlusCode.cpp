#include "SlotForCallCPlusPlusCode.h"

QString SlotForCallCPlusPlusCode::cplusplusCodeToCall(QString stringJavaScriptPackagedInQt,const QVariantList& vetJavaScriptPackagedInQt, int intJavaScript){
    QString convert;
    QString ret;
    ret.clear();
    //Convert the javascript arguments to C-ANSI arguments======================================
    double *vetJavascriptUnpackaged=(double *)malloc(vetJavaScriptPackagedInQt.size()*sizeof(double));
    for(int i =0 ;i < vetJavaScriptPackagedInQt.size();i++ ){
        vetJavascriptUnpackaged[i]=vetJavaScriptPackagedInQt[i].toFloat();
    }
    QByteArray ba = stringJavaScriptPackagedInQt.toLocal8Bit();
    const char* stringJavaScript= ba.data();

    //End=======================================================================================
    ret.append("[\"");
    ret.append(this->applicationDirPath);
    ret.append("\",");

    for(int i =0 ;i < vetJavaScriptPackagedInQt.size();i++ ){
        ret.append(convert.setNum(vetJavascriptUnpackaged[i]*(double)intJavaScript));
   
        ret.append(",");
    }
    ret.append("\"");
    ret.append(stringJavaScript);
    ret.append("\"");
    ret.append("]");
    free(vetJavascriptUnpackaged);
   
    return ret;
}
