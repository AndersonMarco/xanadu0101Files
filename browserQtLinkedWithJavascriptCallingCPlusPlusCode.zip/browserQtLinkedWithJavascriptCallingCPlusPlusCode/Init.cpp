#include <QApplication>
#include <QDebug>
#include <QWebFrame>
#include <QWebPage>
#include <QWebView>
#include <QWebSettings>
#include "SlotForCallCPlusPlusCode.h"

int main(int argc, char** argv){
    QApplication app(argc, argv);


    QString convert;
    convert.clear();
    convert.append(qApp->applicationDirPath());

    QWebView *view= new QWebView();
    view->page()->mainFrame()->addToJavaScriptWindowObject("callCodeCPlusPlus", new SlotForCallCPlusPlusCode(qApp->applicationDirPath()));
    //enable debug of javascrip================================================
    view->settings()->setAttribute(QWebSettings::DeveloperExtrasEnabled,true);
    view->settings()->setAttribute(QWebSettings::DeveloperExtrasEnabled,true);
    //end======================================================================
    view->settings()->setAttribute(QWebSettings::FrameFlatteningEnabled, true);
    view->settings()->setAttribute(QWebSettings::LocalContentCanAccessFileUrls, true);
    view->settings()->setAttribute(QWebSettings::LocalContentCanAccessRemoteUrls, true);
    view->show();
    convert.append("/index.html");
    view->setUrl(QUrl(convert));
    return app.exec();
}
