#!/usr/bin/php
<?php
function getArquivosDir($dir){
	// abre o diretório
	$ponteiro  = opendir($dir);
	// monta os vetores com os itens encontrados na pasta
	while ($nome_itens = readdir($ponteiro)) {
		$itens[] = $nome_itens;
	}
	// ordena o vetor de itens
	sort($itens);
	// percorre o vetor para fazer a separacao entre arquivos e pastas
	foreach ($itens as $listar) {
		// retira "./" e "../" para que retorne apenas pastas e arquivos
		if ($listar!="." && $listar!=".."){
	
			// checa se o tipo de arquivo encontrado é uma pasta
			if (is_dir($listar)) {
				// caso VERDADEIRO adiciona o item à variável de pastas
				$pastas[]=$listar;
			} else{
				// caso FALSO adiciona o item à variável de arquivos
				$arquivos[]=$listar;
			}
		}
	}
	return $arquivos;	
}
function getExtArq($arq){
	$div=split("@:",str_replace(".","@:", $arq));
	$ret="null";
	if(count($div)>1){
		$ret=$div[count($div)-1];
	}
	return $ret;
}
function getArquivosImagens($dir){
        $ret[0]="0";
        $cont=0;
	$arquivos=getArquivosDir($dir);
	foreach ($arquivos as $arq) {
		$extArq=getExtArq($arq);
		if(strcasecmp("jpg", $extArq)==0 || strcasecmp("png", $extArq)==0 || strcasecmp("jpeg", $extArq)==0){
                    $ret[$cont]=$arq;
                    $cont++;
                }
	}
        return $ret;
}
// pega o endereço do diretório
$diretorio = getcwd();
$arqImgLista=getArquivosImagens($diretorio);
echo "<html>\n";
echo "<head>";
echo "<meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\" />";
echo "</head>";
echo "<body>\n";
foreach ($arqImgLista as $img){
    echo "<img src=\"$img\"  style=\"padding:20px 0px 80px 20px; max-width:960px;\"> <br>  \n";
}
echo "</body>\n";
echo "</html>\n";
?>