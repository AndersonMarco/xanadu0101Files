function getClassDivSlide(){//pega um div slide qualquer so para saber o tamanho que um slide possui
     var  elements=document.getElementsByTagName("div");//retorna todos elementos div do html do elemento html   
     return document.getElementById("caos");
     for(i=0; i<elements.length; i++){
          if(elements[i].className=="caos"){
              return elements[i];
        }
    }
}
function getClassDivAjustavel(){//reajusta a div para que ocupe um height proporcional ao height da div slide que a comporta                             
    var  elements=document.getElementsByTagName("div");//retorna todos elementos div do html do elemento html      
    for(i=0; i<elements.length; i++){
        if(elements[i].className=="ajustavel"){//verifica se a div pertence a classe Ajustavel
            elements[i].style.height=(Math.round(this.outerHeight*0.3)+"px";          
            //1000-(Math.round(this.outerHeight-500))
        }    
    }
    
}
window.onresize=getClassDivAjustavel;            
getClassDivAjustavel();
            