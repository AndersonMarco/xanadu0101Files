function aumentar(porcentagem){//aumentar o tamanho de um determinado elemento html, na porcentagem que se
                                  //quizer
    //id->id do elemento html que se deseja aumentar
    //portagem-> o quanto se deseja aumentar, a porcentagem esta no formato decimal com virgula ou seja 0.0 significa 0%, 
    //           0.25 significa 25%, 3.0 significa 300% e etc.

    porcentagem=0.1;
	elemento=$(this).parents("div.imgZoom").find("img");		
	
    var altura =  parseFloat(elemento.attr("height"));
    var largura =  parseFloat(elemento.attr("width"));
    elemento.attr("height",altura+(altura*porcentagem));
    elemento.attr("width",largura+(largura*porcentagem));
}
function diminuir(){//diminui o tamanho de um determinado elemento html, na porcentagem que se
                                  //quizer
    //id->id do elemento html que se deseja diminuir
    //portagem-> o quanto se deseja diminuir, a porcentagem esta no formato decimal com virgula ou seja 0.0 significa 0%, 
    //           0.25 significa 25%, 3.0 significa 300% e etc.
	porcentagem=0.1;
	elemento=$(this).parents("div.imgZoom").find("img");		
	
    var altura =  parseFloat(elemento.attr("height"));
    var largura =  parseFloat(elemento.attr("width"));
    elemento.attr("height",altura-(altura*porcentagem));
    elemento.attr("width",largura-(largura*porcentagem));	
	
}

function modificarHTMLQuadrado(){
       
        elementos=$("div.imgZoom");
        elementos.each( function(index){
            var width=$(this).css("max-width");
            var height=$(this).css("max-height");  
            $(this).html("<table><tr><td class=\"tdIMG\"><div class=\"conteiner\" style=\"max-width:\ "+width+"; max-height:"+height+"; overflow:auto; \" >"+$(this).html()+"</div></td></tr> <tr><td  align=center><p><center><table style=\"margin-top:-30px;\" ><tr><td>zoom: </td> <td style=\"padding-top:15px;\"><input  type=image src=\"skins/botaoMais.png \"  class=\"botaoImg botaoAumentar\" value=\"+\" \"></td> <td  style=\"padding-top:15px;\"><input type=image src=\"skins/botaoMenos.png\" class=\"botaoImg botaoDiminuir\" type=button value=\"-\" ></td></tr></table></center></p></td></tr></table>");
        });
        $("div.imgZoom").css("max-width","");
        $("div.imgZoom").css("max-height","");          
        $(".botaoAumentar").click(aumentar);
        $(".botaoDiminuir").click(diminuir);
}
$(document).ready(function(){
	
});
