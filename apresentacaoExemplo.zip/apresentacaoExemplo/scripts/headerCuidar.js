var  elements=document.getElementsByTagName("h1");//retorna todos elementos div do html do     
    for(i=0; i<elements.length; i++){
        
         if(elements[i].parentNode.className=="slide"){
             elements[i].innerHTML="<img src=\"graphics/icon-blue.png\" style=\"vertical-align: middle;\" alt=\"W3C logo\"/> <span style=\"vertical-align: middle;\">"+elements[i].innerHTML +"</span>";            
         }
    }
$("#textoRodape2001").css("margin","30px");
