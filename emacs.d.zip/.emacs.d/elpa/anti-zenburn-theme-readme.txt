Derived from Bozhidar Batsov's port of the Zenburn theme
located here https://github.com/bbatsov/zenburn-emacs
