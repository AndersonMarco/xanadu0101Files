See also
 - http://www.emacswiki.org/emacs/PopUp

Original code is created by LinhDang
