This is an Emacs 24 port of underwater-mod.vim by Mario Gutierrez
from URL `http://www.vim.org/scripts/script.php?script_id=3132'.

To use this theme, download it to ~/.emacs.d/themes. In your `.emacs'
or `init.el', add this line:

  (add-to-list 'custom-theme-load-path "~/.emacs.d/themes")

Once you have reloaded your configuration (`eval-buffer'), do `M-x
load-theme' and select "underwater".
