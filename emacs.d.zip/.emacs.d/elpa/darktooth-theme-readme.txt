A remix of the excellent theme Gruvbox.
