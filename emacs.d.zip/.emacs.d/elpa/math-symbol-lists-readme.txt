This is a "storage" package used by completion engines such as
`company-math.el` and `ac-math.el`.

Defined (a)lists are:

         symbols-math-basic
         symbols-math-extended
         symbols-latex-commands
