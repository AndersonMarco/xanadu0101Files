Use the colors defined in your .Xresources as your emacs theme
