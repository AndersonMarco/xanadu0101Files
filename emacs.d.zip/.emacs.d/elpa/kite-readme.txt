Kite is a front-end for the WebKit inspector remote API.  It allows
to debug web applications running in a WebKit browser instance and
aims to provide functionality similar to the default inspector
front-end built into WebKit browsers.


