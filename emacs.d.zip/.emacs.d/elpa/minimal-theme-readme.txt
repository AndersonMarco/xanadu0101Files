A minimalistic color theme to avoid distraction with
colors. Based on monochrome theme.
