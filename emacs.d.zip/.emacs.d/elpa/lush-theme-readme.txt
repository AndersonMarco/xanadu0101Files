Lush, A Dark Theme with strong colors for Emacs24

Change History:
  Andre Richter, 2014-09:
    * Changed colors for personal taste
    * Made Emacs24 out-of-the-box compatible


This theme is based on JD Huntington's Blackboard theme.
Following is the original info from the theme (with obsolete install instructions):

  Blackboard Colour Theme for Emacs.

  Defines a colour scheme resembling that of the original TextMate Blackboard colour theme.
  To use add the following to your .emacs file (requires the color-theme package):

  (require 'color-theme)
  (color-theme-initialize)
  (load-file "~/.emacs.d/themes/color-theme-blackboard.el")

  And then (color-theme-blackboard) to activate it.

  MIT License Copyright (c) 2008 JD Huntington <jdhuntington at gmail dot com>
  Credits due to the excellent TextMate Blackboard theme

  All patches welcome
