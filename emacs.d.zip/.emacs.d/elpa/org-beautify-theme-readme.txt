An attempt to improve the typography of an org-mode file.

Load this theme over top your existing theme, and you should
be golden.  If you find any incompatibilities, let me know
with what theme and I will try and fix it.

This is part of the Emagicians Starter kit--but available
separately.

When loading a whole new theme overtop, org-beautify-theme will
still be active with the old theme.  Just unload org-beautify-theme
and then reload it, and everything will be fine again.

The Source for this file is here:
https://github.com/jonnay/emagicians-starter-kit/blob/master/themes/org-beautify-theme.org
