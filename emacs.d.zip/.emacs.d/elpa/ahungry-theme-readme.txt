Bright and bold color theme for GNU Emacs.

If you load it from a terminal, you will be able to make use of the
transparent background.  If you load it from a GUI, it will default
to a dark background.
