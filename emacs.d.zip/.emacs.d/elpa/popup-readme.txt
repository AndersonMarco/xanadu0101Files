popup.el is a visual popup user interface library for Emacs. This
provides a basic API and common UI widgets such as popup tooltips
and popup menus.
See README.markdown for more information.
