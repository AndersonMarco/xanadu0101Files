#!/bin/bash

echo "Running autoreconf..."

autoreconf -i
