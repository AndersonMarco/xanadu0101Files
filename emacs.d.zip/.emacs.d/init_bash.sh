alias ls="ls --color"
export LS_COLORS="di=0;36"
alias emacsclient="emacsclient -n"
alias emacsclient="emacsclient -n"
alias emacs="emacsclient -n"
alias pdflatex="lualatex -synctex=1"
export PATH=$PATH:$HOME/.emacs.d/shellScripts
