#%% [markdown]
# # Introdução
# Este relatório faz uma análise da base de dados **Top 5000 Youtube channels data from Socialblade** (https://www.kaggle.com/mdhrumil/top-5000-youtube-channels-data-from-socialblade), que é uma base com informações sobre os canais mais populares do Youtube. A finalidade deste relatório é dizer quais dos atributos numéricos desta base são os mais importantes para determinar o atributo categórico **Grade**.
#%% [markdown]
#   #  Base de dados e algumas informações sobre ela

#%%
import numpy as np
import pandas as pd
df=pd.read_csv('data.csv',na_values=['--','-- ','  '])

#%% [markdown]
# Uma amostra da base de dados:

#%%
df.head()

#%% [markdown]
# Informações sobre os atributos dos elementos da base de dados:

#%%
df.info()
df.describe()

#%% [markdown]
#   # Tratamento dos dados faltantantes
#%% [markdown]
#   ## **Grade**
#   Visualizar dados para as linhas onde **Grade** é nulo.

#%%
df[df['Grade'].isnull()]

#%% [markdown]
#   Usar a coluna  **Video views** para estimar o Grade, porque é a única coluna numérica que nunca é nula.
#   
#   Média de **Video views**  para cada **Grade**:

#%%
avgsOfVideoViewsForGrades=df.groupby('Grade')['Video views'].mean()
avgsOfVideoViewsForGrades

#%% [markdown]
# Preencher o campo **Grade** da linha, cujo campo Grade esta faltando, com o **Grade** para a qual a média de **Video views** seja a mais perto do **Video views** da linha.

#%%
linesWhereGradeIsNull=df[df['Grade'].isnull()].index
for line in linesWhereGradeIsNull:
    avgVideoViewsForGradeChoosedMinusVideoViewsForLine=0
    gradeChoosedToFill=""
    for grade in avgsOfVideoViewsForGrades.index:
        avgsOfVideoViewsForGradeMinusVideoViewsForLine= avgsOfVideoViewsForGrades[grade]-df.loc[line]['Video views']
        if(gradeChoosedToFill=="" or abs(avgVideoViewsForGradeChoosedMinusVideoViewsForLine)<abs(avgsOfVideoViewsForGradeMinusVideoViewsForLine)):
            avgVideoViewsForGradeChoosedMinusVideoViewsForLine=avgsOfVideoViewsForGradeMinusVideoViewsForLine
            gradeChoosedToFill=grade
        
    df.loc[line,'Grade']=gradeChoosedToFill

#%% [markdown]
#   Resultado do tratamento aplicado:

#%%
df.loc[linesWhereGradeIsNull]

#%% [markdown]
#   ## **Video Uploads**
#   Linhas onde **Video Uploads** é nulo:

#%%
df[df['Video Uploads'].isnull()]

#%% [markdown]
#   Assumir que o **Video Uploads** faltante  da linha é igual a média de **Video Uploads** relacionado com o  **Grade** da linha.
#   Médias de **Videos Uploads** relacionadas com os **Grades**:

#%%
avgsOfVideoUploadsForGrades=df.groupby('Grade')['Video Uploads'].mean()
avgsOfVideoUploadsForGrades


#%%
linesWhereVideoUploadsIsNull=df[df['Video Uploads'].isnull()].index
for line in linesWhereVideoUploadsIsNull:
    df.loc[line,"Video Uploads"]=avgsOfVideoUploadsForGrades.loc[df.loc[line,"Grade"]]

#%% [markdown]
#   Resultado do tratamento aplicado:

#%%
df.loc[linesWhereVideoUploadsIsNull]

#%% [markdown]
#   ## **Subscribers**
#   Algumas linhas onde **Subscribers** é nulo:

#%%
df[df['Subscribers'].isnull()].head(20)

#%% [markdown]
#   Colocar a média de  **Subscribers** relacionada com o **Grade** que a linha possui se este valor é nulo.
#   Médias de **Subscribers** relacionadas com os **Grades**:

#%%
avgsOfSubscribersForGrades=df.groupby('Grade')['Subscribers'].mean()
avgsOfSubscribersForGrades


#%%
linesWhereSubscribersIsNull=df[df['Subscribers'].isnull()].index
for line in linesWhereSubscribersIsNull:
    df.loc[line,"Subscribers"]=avgsOfVideoUploadsForGrades.loc[df.loc[line,"Grade"]]

#%% [markdown]
# Resultado para algumas linhas do tratamento aplicado:

#%%
df.loc[linesWhereSubscribersIsNull].head(20)

#%% [markdown]
#   # Análise exploratória
#   ## Estatística clássica
#%% [markdown]
#   Distribuição para o número de inscritos:

#%%
df['Subscribers'].hist(bins=30)

#%% [markdown]
#   Distribuição para o número de visualizações:

#%%
df['Video views'].hist(bins=30)

#%% [markdown]
#   Filtro para excluir canais fora da curva.

#%%
dfFilter=df[(df['Subscribers'] < 2000000)&(df['Video views'] < 1000000000)]

#%% [markdown]
#   Quantidade de elementos na base filtrada:

#%%
len(dfFilter)

#%% [markdown]
# Dispersão para os elementos da base sem filtro por **Subscribers** e **Video views** :

#%%
import seaborn as sns
import matplotlib.pyplot as plt
sns.set_style('darkgrid')
sns.jointplot(height=7,x=df['Subscribers'], y=df['Video views'])

#%% [markdown]
# Dispersão para os elementos da base com filtro por **Subscribers** e **Video views** :

#%%
sns.jointplot(height=7,x=dfFilter['Subscribers'], y=dfFilter['Video views'])

#%% [markdown]
#   Dispersão dos elementos por **Subscribers** e **Video views** dividio por **Grade**:

#%%
def dateplot(x, y, **kwargs):    
    plt.scatter(x=x, y=y, **kwargs)    
    plt.ticklabel_format(style='sci', axis='x',useOffset=False,scilimits=(0, 4))


g = sns.FacetGrid(dfFilter, col='Grade',height=4)
g = g.map(dateplot, 'Subscribers', 'Video views')

g = sns.FacetGrid(dfFilter, col='Grade',height=4)
g = g.map(dateplot, 'Subscribers', 'Video Uploads')

g = sns.FacetGrid(dfFilter, col='Grade',height=4)
g = g.map(dateplot, 'Video Uploads', 'Video views')


#%% [markdown]
# Boxplot para **Video views** dividio pelo **Grade**:

#%%
sns.boxplot(x="Grade", y="Video views", data=dfFilter,linewidth=2)

#%% [markdown]
# Boxplot para **Subscribers** dividio pelo **Grade**

#%%
sns.boxplot(x="Grade", y="Subscribers", data=dfFilter,linewidth=2)

#%% [markdown]
#   ## Estudando os atributos da base por algoritmos de aprendizado de máquina
# Foi feita uma árvore de decisão para estimar os atributos mais importantes na determinação do atributo **Grade**. A árvore foi feita com todos os elementos da base de dados e sua finalidade não foi de predição e sim de estudar o diagrama da árvore gerada, porque o algoritmo que cria árvores de decisão tende a colocar os atributos mais importantes para a predição do atributo desejado (neste caso o **Grade**) mais próximos do topo do diagrama.
#   
# Diagrama truncado da árvore de decisão:

#%%
import graphviz
from sklearn import tree
clf = tree.DecisionTreeClassifier()
X=df[["Subscribers","Video views","Video Uploads"]]
Y=df["Grade"]
clf = clf.fit(X, Y)
dot_data = tree.export_graphviz(clf, out_file=None, 
                                feature_names=X.columns,  
                                class_names=Y.unique(),  
                                filled=True, rounded=True,
                                max_depth=3,  
                                special_characters=True)
graph = graphviz.Source(dot_data)
graph                                

#%% [markdown]
# Observando o digrama nota-se que o atributo **Video Views** e o **Subscribers** são os mais importantes, isto porque eles são os atributos que mais aparecem nas caixas (nós da árvore) que estão mais altas no digrama. 
# 
# Pode-se observar também que quanto maior o **Video Views**  e o **Subscribers** melhor o **Grade** (assumindo que A++ é o melhor **Grade** e B+ o pior). Para entender isto é necessário entender como se lê o diagrama de uma árvore de decisão, a primeira linha de cada nó da árvore é uma pergunta caso seja respondida como sim deve-se seguir a seta a esquerda e caso o contrario segue-se a direita, o algoritmo da arvore de decisão faz isto ate achar um nó que não possui mais perguntas  (no digrama apresentado apenas o no verde não possui perguntas), caso você não queira ir mais adiante e deseje  parar em um nó que possui perguntas você ainda pode obter uma predição menos acurada que é dada pela ultima linha dentro do nó. Pode-se  notar então que caso seja respondido sim para as perguntas de menor ou igual para **Video Views**  e  **Subscribers** quase sempre é alcançado um nó cuja predição vai ser **Grade** B+.
# 
#%% [markdown]
# Foi realizado um teste com  grupos de modelos de predição diferentes, utilizando validação cruzada para a média e desvio padrão da acurácia, em cada grupo de modelos predição é mudado ou algoritmo de geração do modelo e/ou o conjunto de atributos fornecidos como entrada. A hipótese é que atributos, ou conjuntos de atributos, que criam modelos de predição para o atributo **Grade** com pouca acurácia não são importantes na determinação do **Grade**. Foram testados os modelos predição gerados por redes neurais, KNN e árvore de decisão. Os conjuntos de atributos utilizados foram:
#  - **Subscribers**, **Video views** e **Video Upload**
#  - **Subscribers** e **Video views**
#  - **Subscribers** e **Video Uploads**
#  - **Video Uploads** e **Video views**
#  - **Video views**
#  - **Subscribers**
#  - **Video Uploads**

#%%
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sklearn.neural_network import MLPClassifier
from sklearn import tree
from sklearn import neighbors

def stdScaler(data):
    avg=data.mean()
    std=data.std()
    return data.apply(lambda x: (avg-x)/std )

def applyMachineLearning(clfFactory,X,Y):
    #clfFactory             => Function to create classifier object
    #X                      => Elements attributes  in dataset
    #Y                      => Elements classes in dataset
    kf = KFold(n_splits=10,shuffle=True,random_state=3223)
    acuracy=[]
    for train_index, test_index in kf.split(X):
        X_train,X_test,  = X[train_index], X[test_index]
        Y_train,Y_test  = Y[train_index], Y[test_index]
        clf=clfFactory()
        clf=clf.fit(X_train,Y_train)
        acuracy.append(clf.score(X_test,Y_test))
    return acuracy


#apply z-score to normalization of attributes================================
df['Subscribers StdSca']=stdScaler(df["Subscribers"])
df['Video views StdSca']=stdScaler(df["Video views"])
df['Video Uploads StdSca']=stdScaler(df["Video Uploads"])
#end=========================================================================

##input atributes sets to apply machine learning algorithm===================
xSubVvVu={"name":"Subscribers,Video views e Video Uploads", "data":df[["Subscribers StdSca","Video views StdSca","Video Uploads StdSca"]].values}

xSubVv={"name":"Subscribers e Video views", "data":df[["Subscribers StdSca","Video views StdSca"]].values}
xSubVu={"name":"Subscribers e Video Uploads", "data":df[["Subscribers StdSca","Video Uploads StdSca"]].values}
xVvVu={"name":"Video views e Video Uploads", "data":df[["Video views StdSca","Video Uploads StdSca"]].values}
xVv={"name":"Video views", "data":df[["Video views StdSca"]].values}
xVu={"name":"Video Uploads", "data":df[["Video Uploads StdSca"]].values}
xSub={"name":"Subscribers","data":df[["Subscribers StdSca"]].values}
#end=========================================================================

attributesSets=[xSub,xVu,xVv,xSubVu,xVvVu,xSubVv,xSubVvVu] # vector with the input attributes sets

#Constructors for the machine learning algorithms============================
knnFactory  = lambda : neighbors.KNeighborsClassifier(n_neighbors=5)
treeFactory = lambda : tree.DecisionTreeClassifier()
MLPFactory1  = lambda : MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(16,32,32, 16), random_state=1)
#end=========================================================================

algorithmsToMeasureAcuracy=[
                            {"name":'KNN',"algorithm":knnFactory},                            
                            {"name":'Árvore de decisão',"algorithm":treeFactory},
                            {"name":'Rede neural',"algorithm":MLPFactory1},
                           ]
Y=df["Grade"].values 
accuracyData={}


localizationToShowColumnsAtDataAboutAccuracy=[]

for attributesSet in attributesSets:
    X=attributesSet["data"]
    #print("Conjunto de atributos:" +attributesSet["name"])
    localizationToShowColumnsAtDataAboutAccuracy.append(attributesSet["name"])
    
    avgAcuracy=[]
    stdAcuracy=[]
    for algorithmToMeasureAcuracy in algorithmsToMeasureAcuracy:
        #print("    Nome do algoritmo: "+algorithmToMeasureAcuracy["name"])
        acuracy=applyMachineLearning(algorithmToMeasureAcuracy['algorithm'],X,Y)
       
        avg="{d0:.2f}%".format(d0=np.mean(np.array(acuracy,dtype=float))*100.0)
        std="{d0:.2f}%".format(d0=np.std(np.array(acuracy,dtype=float))*100.0)
        avgAcuracy.append(avg)
        stdAcuracy.append(std)        
        #print("        Média para a acurácia:{d0}%".format(d0=avg))
        #print("        Desvio padrão para a acurácia:{d0}%".format(d0=std ))

    accuracyData[attributesSet["name"]]=avgAcuracy+stdAcuracy

indexForData=[]
for algorithmToMeasureAcuracy in algorithmsToMeasureAcuracy:
    indexForData.append("Média "+algorithmToMeasureAcuracy["name"])
for algorithmToMeasureAcuracy in algorithmsToMeasureAcuracy:
    indexForData.append("Desvio padrão "+algorithmToMeasureAcuracy["name"])    

dataFrameWithTheAccuracyData=pd.DataFrame(accuracyData,index=indexForData)

dataFrameWithTheAccuracyData[localizationToShowColumnsAtDataAboutAccuracy]
#df.head()

#%% [markdown]
# A tabela acima indica que **Video Uploads** é o atributo menos importante. Um dos motivos para isto é porque ele é o atributo que sozinho gerou os modelos com menores acurácias. Os modelos criados pela combinações **Subscribers**+**Video Uploads** e  **Video views**+**Video Uploads** foram piores que os modelos criados pela combinação **Subscribers**+**Video views** o que reforça que **Video Uploads** é o atributo menos importante para determinar o **Grade**, também pode-se observar que em alguns casos os modelos gerados pela combinação de **Video Uploads** com outros atributos são piores que os modelos criados com apenas um atributo algo que da mais força para a indicação de que **Video Uploads** não é importante. 
#%% [markdown]
#  ## Conclusão sobre a análise exploratória
#  Este trabalho estudou como os atributos numéricos da base **Top 5000 Youtube channels data from Socialblade** influenciam o atributo categórico **Grade**. O atributo **Video views** é o mais importante para determinar o **Grade**, seguido pelo **Subscribers**, isto foi observado  pelos dados obtidos na Subseção **Estudando os atributos da base por algoritmos de aprendizado de máquina**. A análise da árvore de decisão gerada na mesma  subseção mostra que quanto maiores estes atributos melhor o **Grade**, assumindo que  A++ é o melhor **Grade** e B+ o pior **Grade**.
#   

