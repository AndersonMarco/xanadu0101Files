#%% [markdown]
#  #  Dados e algumas informações sobre eles

#%%
import numpy as np
import pandas as pd
df=pd.read_csv('data.csv',na_values=['--','-- ','  '])
df.head()


#%%
df['Grade'].unique()


#%%
df.info()
df.describe()

#%% [markdown]
#  # Tratar os dados faltantantes
#%% [markdown]
#  ## **Grade**
#  Visualizar dados disponiveis para as linhas onde **Grade** é nulo.

#%%
df[df['Grade'].isnull()]

#%% [markdown]
#  Usar a coluna vídeo **Video views** para estimar o Grade, porque é a unica coluna numerica que nunca é nula. <br>
#  **Video views** média para cada **Grade**:

#%%
avgsOfVideoViewsForGrades=df.groupby('Grade')['Video views'].mean()
avgsOfVideoViewsForGrades

#%% [markdown]
#  Prencher o campo **Grade** da linha , cujo o campo Grade esta faltando, com **Grade** onde a média de **Video views** seja a mais perto do **Video views** da linha.

#%%
linesWhereGradeIsNull=df[df['Grade'].isnull()].index
for line in linesWhereGradeIsNull:
    avgVideoViewsForGradeChoosedMinusVideoViewsForLine=0
    gradeChoosedToFill=""
    for grade in avgsOfVideoViewsForGrades.index:
        avgsOfVideoViewsForGradeMinusVideoViewsForLine= avgsOfVideoViewsForGrades[grade]-df.loc[line]['Video views']
        if(gradeChoosedToFill=="" or abs(avgVideoViewsForGradeChoosedMinusVideoViewsForLine)<abs(avgsOfVideoViewsForGradeMinusVideoViewsForLine)):
            avgVideoViewsForGradeChoosedMinusVideoViewsForLine=avgsOfVideoViewsForGradeMinusVideoViewsForLine
            gradeChoosedToFill=grade
        
    df.loc[line,'Grade']=gradeChoosedToFill

#%% [markdown]
#  Resultado do tratamento aplicado:

#%%
df.loc[linesWhereGradeIsNull]

#%% [markdown]
#  ## **Video Uploads**
#  Linhas onde **Video Uploads** é nulo:

#%%
df[df['Video Uploads'].isnull()]

#%% [markdown]
#  Colocar a media de  **Video Uploads** relacionada com o **Grade** que a linha pertence se este valor é nulo.
#  Médias de **Videos Uploads** relacionadas com os **Grades**:

#%%
avgsOfVideoUploadsForGrades=df.groupby('Grade')['Video Uploads'].mean()
avgsOfVideoUploadsForGrades


#%%
linesWhereVideoUploadsIsNull=df[df['Video Uploads'].isnull()].index
for line in linesWhereVideoUploadsIsNull:
    df.loc[line,"Video Uploads"]=avgsOfVideoUploadsForGrades.loc[df.loc[line,"Grade"]]

#%% [markdown]
#  Resultado do tratamento aplicado:

#%%
df.loc[linesWhereVideoUploadsIsNull]

#%% [markdown]
#  ## **Subscribers**
#  Linhas onde **Subscribers** é nulo:

#%%
df[df['Subscribers'].isnull()]

#%% [markdown]
#  Colocar a media de  **Subscribers** relacionada com o **Grade** que a linha pertence se este valor é nulo.
#  Médias de **Subscribers** relacionadas com os **Grades**:

#%%
avgsOfSubscribersForGrades=df.groupby('Grade')['Subscribers'].mean()
avgsOfSubscribersForGrades


#%%
linesWhereSubscribersIsNull=df[df['Subscribers'].isnull()].index
for line in linesWhereSubscribersIsNull:
    df.loc[line,"Subscribers"]=avgsOfVideoUploadsForGrades.loc[df.loc[line,"Grade"]]

#%% [markdown]
#  Resultado do tratamento aplicado:

#%%
df.loc[linesWhereSubscribersIsNull]

#%% [markdown]
#  # Analíse exploratória
#  ## Estatística clássica

#%% [markdown]
#  Distribuição para o número de inscritos

#%%
df['Subscribers'].hist(bins=30)

#%% [markdown]
#  Distribuição para o número de visualizações

#%%
df['Video views'].hist(bins=30)

#%% [markdown]
#  Filtro para excluir canais fora da curva.

#%%
dfFilter=df[(df['Subscribers'] < 2000000)&(df['Video views'] < 1000000000)]

#%% [markdown]
#  Quantidade de dados na base filtrada:

#%%
len(dfFilter)

#%% [markdown]
#  Analíse de dispersão para os elementos por **Subscribers** e **Video views** sem filtro
#%%
import seaborn as sns
import matplotlib.pyplot as plt
sns.set_style('darkgrid')
sns.jointplot(size=7,x='Subscribers', y='Video views',data=df)


#%% [markdown]
#  Analíse de dispersão para os elementos por Subscribers e Video views** com filtro
#%%
sns.jointplot(size=7,x='Subscribers', y='Video views',data=dfFilter)
plt.ticklabel_format(style='sci', axis='x',useOffset=False,scilimits=(0, 4))



#%% [markdown]
#  Analíse de dispersão para os elementos por **Subscribers** por **Video views** dividio pela Grade


#%%
def dateplot(x, y, **kwargs):    
    plt.scatter(x=x, y=y, **kwargs)    
    plt.ticklabel_format(style='sci', axis='x',useOffset=False,scilimits=(0, 4))


g = sns.FacetGrid(dfFilter, col='Grade',size=4)
g = g.map(dateplot, 'Subscribers', 'Video views')

g = sns.FacetGrid(dfFilter, col='Grade',size=4)
g = g.map(dateplot, 'Subscribers', 'Video Uploads')

g = sns.FacetGrid(dfFilter, col='Grade',size=4)
g = g.map(dateplot, 'Video Uploads', 'Video views')



#%% [markdown]
#  Analíse de boxplot para **Video views** dividio pela Grade
#%%
sns.boxplot(x="Grade", y="Video views", data=dfFilter,linewidth=2)

#%% [markdown]
#  Analíse de boxplot para **Subscribers** dividio pela Grade
#%%
sns.boxplot(x="Grade", y="Subscribers", data=dfFilter,linewidth=2)


             


#%% [markdown]
#  ## Estudar atributos das bases por algoritmos de aprendizado de maquina
#  Arvore de decisão para ver os elementos mais importantes
import graphviz
from sklearn import tree
clf = tree.DecisionTreeClassifier()
X=df[["Subscribers","Video views","Video Uploads"]]
Y=df["Grade"]
clf = clf.fit(X, Y)
dot_data = tree.export_graphviz(clf, out_file=None, 
                                feature_names=X.columns,  
                                class_names=Y.unique(),  
                                filled=True, rounded=True,
                                max_depth=3,  
                                special_characters=True)
graph = graphviz.Source(dot_data)
graph                                


#%% [markdown]
# Testar grupos de modelos predição diferentes, utilizando validação cruzada para a acuracia,  em cada grupo de modelos predição é mudado ou algoritmo de geração do modelo ou o conjunto de atributos fornecidos como entrada. Foram testados os modelos predição gerados por redes neurais, KNN e arvore de decisão. Os conjuntos de atributos utilizados foram:
# - **Subscribers**,**Video views**,**Video Upload**
# - **Subscribers**,**Video views**
# - **Subscribers**,**Video Uploads**
# - **Video Uploads**,**Video views**
# - **Video views**
# - **Subscribers**
# - **Video Uploads**

#%%
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sklearn.neural_network import MLPClassifier
from sklearn import tree
from sklearn import neighbors

def stdScaler(data):
    avg=data.mean()
    std=data.std()
    return data.apply(lambda x: (avg-x)/std )

def applyMachineLearning(clfFactory,X,Y):
    #clfFactory             => Function to create classifier object
    #X                      => Elements attributes  in dataset
    #Y                      => Elements classes in dataset
    kf = KFold(n_splits=10,shuffle=True,random_state=3223)
    acuracy=[]
    for train_index, test_index in kf.split(X):
        X_train,X_test,  = X[train_index], X[test_index]
        Y_train,Y_test  = Y[train_index], Y[test_index]
        clf=clfFactory()
        clf=clf.fit(X_train,Y_train)
        acuracy.append(clf.score(X_test,Y_test))
    return acuracy

df['Subscribers StdSca']=stdScaler(df["Subscribers"])
df['Video views StdSca']=stdScaler(df["Video views"])
df['Video Uploads StdSca']=stdScaler(df["Video Uploads"])

xSubVvVu={"name":"[Subscribers,Video views,Video Uploads]", "data":df[["Subscribers StdSca","Video views StdSca","Video Uploads StdSca"]].values}

xSubVv={"name":"[Subscribers,Video views]", "data":df[["Subscribers StdSca","Video views StdSca"]].values}
xSubVu={"name":"[Subscribers,Video Uploads]", "data":df[["Subscribers StdSca","Video Uploads StdSca"]].values}
xVvVu={"name":"[Video views,Video Uploads]", "data":df[["Video views StdSca","Video Uploads StdSca"]].values}
xVv={"name":"[Video views]", "data":df[["Video views StdSca"]].values}
xVu={"name":"[Video Uploads]", "data":df[["Video Uploads StdSca"]].values}
xSub={"name":"[Subscribers]","data":df[["Subscribers StdSca"]].values}


attributesSets=[xSub,xVu,xVv,xSubVu,xVvVu,xSubVv,xSubVvVu]

knnFactory  = lambda : neighbors.KNeighborsClassifier(n_neighbors=5)
treeFactory = lambda : tree.DecisionTreeClassifier()
#MLPFactory1  = lambda : MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(16,32,32,32,32,32,32,32, 16), random_state=1)
MLPFactory1  = lambda : MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(16,32,32, 16), random_state=1)
algorithmsToMeasureAcuracy=[
                            {"name":'KNN',"algorithm":knnFactory},                            
                            {"name":'Árvore de decisão',"algorithm":treeFactory},
                            #{"name":'Rede neural',"algorithm":MLPFactory1},
                           ]
Y=df["Grade"].values
dataAboutAcuracy={}


localizationToShowColumnsAtDataAboutAccuracy=[]

for attributesSet in attributesSets:
    X=attributesSet["data"]
    print("Conjunto de atributos:" +attributesSet["name"])
    localizationToShowColumnsAtDataAboutAccuracy.append(attributesSet["name"])
    
    avgAcuracy=[]
    stdAcuracy=[]
    for algorithmToMeasureAcuracy in algorithmsToMeasureAcuracy:
        print("    Nome do algoritmo: "+algorithmToMeasureAcuracy["name"])
        acuracy=applyMachineLearning(algorithmToMeasureAcuracy['algorithm'],X,Y)
       
        avg="{d0:.2f}%".format(d0=np.mean(np.array(acuracy,dtype=float))*100.0)
        std="{d0:.2f}%".format(d0=np.std(np.array(acuracy,dtype=float))*100.0)
        avgAcuracy.append(avg)
        stdAcuracy.append(std)        
        #print("        Média para a acurácia:{d0}%".format(d0=avg))
        #print("        Desvio padrão para a acurácia:{d0}%".format(d0=std ))

    dataAboutAcuracy[attributesSet["name"]]=avgAcuracy+stdAcuracy

indexForData=[]
for algorithmToMeasureAcuracy in algorithmsToMeasureAcuracy:
    indexForData.append("Média "+algorithmToMeasureAcuracy["name"])
for algorithmToMeasureAcuracy in algorithmsToMeasureAcuracy:
    indexForData.append("Desvio padrão "+algorithmToMeasureAcuracy["name"])    

dd=pd.DataFrame(dataAboutAcuracy,index=indexForData)

dd[localizationToShowColumnsAtDataAboutAccuracy]
#df.head()
#%% [markdown]
# ## Conclusão sobre a analíse exploratória
#  A atributo Video views, seguido pelo **Subscribers**, é o mais importante para determinar o Grade de um canal.



